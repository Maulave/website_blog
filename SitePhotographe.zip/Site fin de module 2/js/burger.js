/* -------------------------------------------------------------------------- */
/*                                 BURGER MENU                                */
/* -------------------------------------------------------------------------- */

// On récupere nos ID //

var burgerMenu = document.getElementById("burger-menu");
var burgerClose = document.getElementById("burger-close");
var burgerIncone = document.getElementById("burger-icone");
var listeNavigation = document.querySelectorAll(".liste")

// On crée une variable click et on l'initialise a false //
// Quan dl'utilisateur click click devient true
var click = false;

// On appel la fonction quand l'utilisateur appuie sur le burger-menu //
burgerIncone.addEventListener("click", event => {

    // Si click est égale a false, le burger prend une largeur de 40vw //
    if(click === false) { 
    burgerMenu.style.cssText = "width: 45vw";

    // tant que i = 0, si i est plus petit que le nombre de balise contenant la class = liste,
    // i est invrémenté de 1
    // on display : flex chaque entré du tableau
    for(var i = 0; i<listeNavigation.length; i++){
        listeNavigation[i].style.cssText = "display: flex";
    }

    click = true;
    } else if (click === true){
        burgerMenu.style.cssText = "width: 0vw";

        // tant que i = 0, si i est plus petit que le nombre de balise contenant la class = liste,
        // i est invrémenté de 1
        // on display : none chaque entré du tableau pour enlever la liste
        for(var i = 0; i<listeNavigation.length; i++){
            listeNavigation[i].style.cssText = "display: none";
        }

        // click devient false //
        click = false;
    }
});


// On appel la fonction quand l'utilisateur appuie sur le bouton fermé //
burgerClose.addEventListener("click", event => {

    if (click === true){

        for(var i = 0; i<listeNavigation.length; i++){
            listeNavigation[i].style.cssText = "display: none";
        }

        burgerMenu.style.cssText = "width: 0vw";
        click = false;

    } else {}
})
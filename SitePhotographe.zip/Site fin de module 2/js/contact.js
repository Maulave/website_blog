/* -------------------------------------------------------------------------- */
/* -------------------------------------------------------------------------- */
/* -------------------------------------------------------------------------- */

/*                            FORMULAIRE DE CONTACT                           */

/* -------------------------------------------------------------------------- */
/* -------------------------------------------------------------------------- */
/* -------------------------------------------------------------------------- */


/* Stocke la valeur de l'input name, prenom, email, portable */
var inputName = document.getElementById("name");
var inputPrenom = document.getElementById("prenom")
var inputEmail = document.getElementById("email")
var inputTelephone = document.getElementById("phoneNumber")
var elemInput = document.querySelectorAll("input");



/* On initialise la valeur dataName a String étant "vide" */
var dataName = "";
var dataPrenom = "";
var dataEmail = "";
var dataTelephone = "";

/* Stocke la box pour le messsage */
var messageBox = document.getElementsByClassName("message");



/* Récupérer le nom de la fonction attribué */
function getForm() {

    /* on crée une variable peps dans lequel on recupere toute nos balise p du formulaire */
    var peps = document.querySelectorAll("form p");
    console.log(peps);

    /* on verifie si la longueur de peps est pas égale a 0 */
    if (peps.length != 0) {
    
    /* Pour i = 0, tant que i est plus petit que la longueur de peps, on ajoute +1 a i */
        for (i = 0 ; peps.length > i ; i++ ){
    /* on verifie tout les éléments de peps grace a [i] et on remove chaque élément une fois qu'on clique sur "envoyer" */
            peps[i].remove();
        }
    }


/* -------------------------------------------------------------------------- */
/*                                 INPUT NAME                                 */
/* -------------------------------------------------------------------------- */

    var dataName = inputName.value;

    /* Définir le regEXP */
    let regName = /^[A-Z][a-z]+$/;
    
    /* Check si l'input suit les condition du regEXP */
    if (regName.test(dataName)) {
        regName = true;
    } else {
        regName = false;
    }

    console.log(regName)

/* -------------------------------------------------------------------------- */
/*                                INPUT PRENOM                                */
/* -------------------------------------------------------------------------- */

    var dataPrenom = inputPrenom.value;

    /* Définir le regEXP */
    let regPrenom = /^[A-Z][a-z]+$/;

    if (regPrenom.test(dataPrenom)) {
        regPrenom = true;
    } else {
        regPrenom = false;
    }

/* -------------------------------------------------------------------------- */
/*                                 INPUT EMAIL                                */
/* -------------------------------------------------------------------------- */

    var dataEmail = inputEmail.value;

    /* Définir le regEXP */
    let regEmail = /^([a-z0-9][a-z0-9._-]+)@([a-z0-9][a-z0-9._-]+)\.([a-z]){2,}$/;

    if (regEmail.test(dataEmail)) {
        regEmail = true;
    } else {
        regEmail = false;
    }

/* -------------------------------------------------------------------------- */
/*                               INPUT TELEPHONE                              */
/* -------------------------------------------------------------------------- */

    var dataTelephone = inputTelephone.value;


    /* Définir le regEXP */
    let regTelephone = /(^[0]{1})([6-7]{1})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})$/;

    if (regTelephone.test(dataTelephone)) {
        regTelephone = true;
    } else {
        regTelephone  = false;
    }

/* -------------------------------------------------------------------------- */
/*                                  ALL INPUT                                 */
/* -------------------------------------------------------------------------- */
    
    // NOM //
    if (regName === true) {
        inputName.style.cssText = "border-bottom : 1px solid var(--secondary);";

    } else if(regName === false) {
        inputName.style.cssText = "border-bottom : 1px solid red";
        var newParagraphe = document.createElement("p");
        newParagraphe.textContent = 'Votre "Nom" doit commencer par une "MAJUSCULE" suivis de "minuscules"';
        var newAttribut = document.createAttribute("id");
        newAttribut.value = "messageError";
        newParagraphe.setAttributeNode(newAttribut);
        messageBox[0].insertAdjacentElement('afterbegin', newParagraphe);
    } 

    // PRENOM //

    if (regPrenom === true) {
        inputPrenom.style.cssText = "border-bottom : 1px solid var(--secondary);";

    } else if(regPrenom === false) {
        inputPrenom.style.cssText = "border-bottom : 1px solid red";
        var newParagraphe = document.createElement("p");
        newParagraphe.textContent = 'Votre "Prenom" doit commencer par une "MAJUSCULE" suivis de "minuscules"';
        var newAttribut = document.createAttribute("id");
        newAttribut.value = "messageError";
        newParagraphe.setAttributeNode(newAttribut);
        messageBox[1].insertAdjacentElement('afterbegin', newParagraphe);
    } 

    // EMAIL //

    if (regEmail === true) {
        inputEmail.style.cssText = "border-bottom : 1px solid var(--secondary);";
    
    } else if(regEmail === false) {
        inputEmail.style.cssText = "border-bottom : 1px solid red";
        var newParagraphe = document.createElement("p");
        newParagraphe.textContent = "Votre 'Email' n'est pas conforme";
        var newAttribut = document.createAttribute("id");
        newAttribut.value = "messageError";
        newParagraphe.setAttributeNode(newAttribut);
        messageBox[2].insertAdjacentElement('afterbegin', newParagraphe);
    } 

    
    // NUMERO //

    if (regTelephone === true) {
        inputTelephone.style.cssText = "border-bottom : 1px solid var(--secondary);";
    
    } else if(regTelephone === false) {
        inputTelephone.style.cssText = "border-bottom : 1px solid red";
        var newParagraphe = document.createElement("p");
        newParagraphe.textContent = "Votre 'NUMERO' n'est pas conforme";
        var newAttribut = document.createAttribute("id");
        newAttribut.value = "messageError";
        newParagraphe.setAttributeNode(newAttribut);
        messageBox[3].insertAdjacentElement('afterbegin', newParagraphe);
    } 
}


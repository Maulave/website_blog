/* -------------------------------------------------------------------------- */
/*                               DRAG IMMOBILIER                              */
/* -------------------------------------------------------------------------- */
/*
// On appel nos balise //
var drag = document.getElementById("drag");
var largeur = document.getElementById("photoImmovable")
var positionImage = document.getElementById("after")

// Sert a déterminer la position d'un élément //
var objetRect = drag.getBoundingClientRect();
var objectLargeur = largeur.getBoundingClientRect();
var objectPositionImage = positionImage.getBoundingClientRect();

// Si ma souris bouge alors cela active la fonction "onMouseMove" //
document.onmousemove = onMouseMove;
// Si je lache le click de ma souri alors cela active la fonction "onMouseUp" //
document.onmouseup = onMouseUp;

// x est l'axe sur lequel je bouge mon élément //
// objectRect.left met permet de récuprer la valeur des x dans la variable x //
x = objetRect.left;
// w est la largeur de mon élément (#photoImmovable) //
w = objectLargeur.width;
// x est la position de mon élément image //
oi = objectPositionImage.left;


console.log(objectLargeur.width)
// j'initialise mouseDown a false //
var mouseDown = false;

// Si est actif alors cela renvoie la valeur true //
function onMouseDouwn(event) {
    mouseDown = true;
}

// Si onMouseUp est activé, mouseDown devient false et mon élément ne bougera plus //
function onMouseUp(event) {
    mouseDown = false;
}

// fonction onMouseMove //
function onMouseMove(event) {

    // Si je clique sur mon élément, cela renvoie true //
    /*  if (mouseDown === true) {

        // On éxécute alors notre style //
        // event.clientX me permet d'avoir la postion horizontale de ma souris(x) //
        // moins la position de mon élément sur l'axe horizontal //
        drag.style.left = (event.clientX - objetRect.left) / 4.7 + 50 + '%';
        positionImage.style.right = (objetRect.left - event.clientX) / 4.7 + 50 + '%';
    } 
    */

        // Si clientX - ObjectRect.left est supérieur a la largeur de mon élément//
        // alors ma variable drag ne sera pas plus grande sur les (x) //
        // que la largeur de mon élément -2 (-2 qui est la width ma drag) //
/*
    if (mouseDown === true) {

        if(event.clientX - objetRect.left >= objectLargeur.width - (objectLargeur.width / 2)) {

            drag.style.left = objectLargeur.width - 4 + 'px';
            positionImage.style.right = 0 + '%';
        }
    }

        // Si clientX - ObjectRect.left est inférieur a la largeur de mon élément//
        // alors ma variable drag ne sera pas plus petite sur les (x) //
        // que la largeur de mon élément //
    if (mouseDown === true) {

        if(event.clientX - objetRect.left <= objectLargeur.width - objectLargeur.width - 233) {

            drag.style.left = 0 + '%';
        }
    }
}

*/


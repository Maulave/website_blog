/* -------------------------------------------------------------------------- */
/* -------------------------------------------------------------------------- */
/* -------------------------------------------------------------------------- */

/*                                   SLIDER                                   */

/* -------------------------------------------------------------------------- */
/* -------------------------------------------------------------------------- */
/* -------------------------------------------------------------------------- */

/* On récupère nos images dans un tableau */
const images = document.getElementsByClassName("image-slider");
console.log(images);

/* On recupere nos images dans un tableau pour avoir la nombres d'entrées */
const imageSlide = images.length;

/* On crée une variable count et on 'linitialise a 0 */
let count = 0;

/* on crée une fonction qui prendra le slide */
setInterval(function slider(){

/* la classe active presente sur la photo en question disparaitra */
    images[count].classList.remove('active');


/* Si count est plus petit que le nombre d'imageSlide -1 (-1 car le tableau comme a 0)
alors count est incrémenté de 1. Sinon si, il est au dessus de 2 count prend la valeur 0 */
    if(count < imageSlide -1){
        count++;
    } else {
        count = 0;
    }

/* on donne la class = active à la nouvelle image definit par [count] */
    images[count].classList.add('active');
    
}, 5000)